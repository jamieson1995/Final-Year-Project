To run this program simply double click on the ShopManager.exe file
or right click on it and select run open.
